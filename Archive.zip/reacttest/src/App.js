import React from 'react';
import './App.css';
import { Route, Link, Routes } from 'react-router-dom';
import Home from './components/home';
import About from './components/about';
import Movies from './components/movies';

const App = () => {
  return (
    <div className="app-container">
        <nav>
          <ul>
            <li>
              <Link to="/">Home</Link>
            </li>
            <li>
              <Link to="/about">About Us</Link>
            </li>
            <li>
              <Link to="/movies">Movies</Link>
            </li>
          </ul>
        </nav>
        <Routes>
          <Route exact path="/" element={<Home/>} />
          <Route path="/about" element={<About/>} />
          <Route path="/movies" element={<Movies/>} />
        </Routes>
    </div>
  );
};

export default App;
