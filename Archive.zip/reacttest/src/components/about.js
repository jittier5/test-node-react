import React from 'react'

export default function About() {
  return (
    <h1>This is about page</h1>
  )
}
