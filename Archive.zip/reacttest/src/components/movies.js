import React, { useEffect, useState } from 'react'
import { MovieService } from '../services/Movies.services';

export default function Movies() {
    const [movies, setMovies] = useState([]);
    const [hasError, setError] = useState('')

    const fetchMovies = async () => {
        try {
            const data = await MovieService.getMovies();
            setMovies(data)
        } catch (e) {
            setError(e.message)
        }
    }

    useEffect(() => {
        fetchMovies()
    }, [])

    return (
        <div className="card-list">
            {movies.length ? movies.map((card, index) => (
                <div key={index} className="card">
                    <h2 className="card-title">{card.name}</h2>
                    <h5><small>Rating: </small>{card.rating}</h5>
                    <p className="card-description">{card.releaseDate}</p>
                </div>
            )) : <h1>No movies found</h1>}
            {hasError ? <h1>{hasError}</h1>: ''}
        </div>
    )
}
