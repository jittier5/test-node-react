import axios from "axios";
const url = "http://localhost:8080/movies"

let headers = {
    "Content-Type": "application/json",
  };

export const MovieService = {
    getMovies: async () => {
        try {
            const res = await axios.get(url, {headers: headers})
            return res.data
        } catch (error) {
            throw new Error("Error getting list of movies")
        }
    }
}